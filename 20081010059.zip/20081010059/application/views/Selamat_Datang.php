<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Go Live</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('Assets/css/bootstrap.min.css')?>"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('Assets/css/header.css')?>"/>
</head>
<body>
<header class="site-header">
            <div class="site-identity">
                <h1><a href="#">WELCOME TO GOLIVE</a></h1>
            </div>
            <nav class="site-navigation">
                <ul class="nav">
                    <li><a href="<?php echo base_url() ?>">Home</a></li>
                    <li><a href="<?php echo base_url('index.php/author/Halaman_Harga') ?>">Produk</a></li>
                </ul>
            </nav>
        </header>
</body>
</html>